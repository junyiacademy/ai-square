# AI 快速參考指南

## 專案結構
```
frontend/           # Next.js + TypeScript + Tailwind
backend/            # FastAPI + Python
docs/tickets/       # 工作票券（YAML）
```

## 常用命令
```bash
make new TYPE=feature TICKET=dark-mode    # 開始
make save                                  # 保存
make done                                  # 完成
```

## Ticket 格式
```yaml
ticket: T123
feature: 功能名稱
acceptance_criteria:
  - 條件1
  - 條件2
```

## Git Commit 格式
```
feat(scope): 描述
fix(scope): 描述
chore(scope): 描述
```

## 測試指令
```bash
# Frontend
cd frontend && npm test
cd frontend && npm run typecheck

# Backend  
cd backend && python -m pytest
```

## API 結構
```
GET  /api/relations?lang={lang}
POST /api/auth/login
```

## 常見模式

### React Context
```typescript
const ThemeContext = createContext<ThemeContextType>()
export const useTheme = () => useContext(ThemeContext)
```

### API Route (Next.js)
```typescript
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  return NextResponse.json(data)
}
```

### i18n
```typescript
const { t, i18n } = useTranslation('common')
t('key')
```

## 環境變數追蹤
```bash
PROMPT_TOKENS=1500 COMPLETION_TOKENS=3000 make save
```