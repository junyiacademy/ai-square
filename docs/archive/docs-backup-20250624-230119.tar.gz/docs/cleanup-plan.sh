#!/bin/bash
# Docs 清理和重組計劃

echo "📦 開始 docs 目錄清理和重組..."

# Phase 1: 備份當前狀態
echo "1️⃣ 備份當前 docs..."
tar -czf docs-backup-$(date +%Y%m%d-%H%M%S).tar.gz docs/
echo "✅ 備份完成"

# Phase 2: 清理垃圾文件
echo "2️⃣ 清理垃圾文件..."
find docs -name "*.pyc" -delete
find docs -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find docs -name ".DS_Store" -delete
echo "✅ 清理完成"

# Phase 3: 統計現狀
echo "3️⃣ 統計分析..."
echo "- Scripts 數量: $(ls docs/scripts/*.py 2>/dev/null | wc -l)"
echo "- Dev logs 數量: $(find docs/dev-logs -name "*.yml" 2>/dev/null | wc -l)"
echo "- Handbook 文件: $(find docs/handbook -name "*.md" 2>/dev/null | wc -l)"
echo "- 已完成票券: $(find docs/tickets/completed -name "*.yml" 2>/dev/null | wc -l)"

# Phase 4: 創建新結構（預覽）
echo "4️⃣ 建議的新結構："
cat << 'EOF'
docs/
├── tickets/
│   ├── active/      # 進行中票券
│   └── archive/     # 歸檔（壓縮）
├── handbook/
│   └── AI-QUICK-REFERENCE.md
├── scripts/         # 5-8 個核心腳本
└── reports/         # 自動生成報告
    ├── weekly/
    └── metrics/
EOF

echo ""
echo "🤔 是否執行重組? 這將："
echo "  - 將 57 個腳本精簡到 8 個"
echo "  - 將 80+ handbook 文件合併為 1 個"
echo "  - 歸檔所有已完成票券"
echo "  - 刪除重複的備份目錄"
echo ""
echo "執行: bash docs/cleanup-plan.sh --execute"