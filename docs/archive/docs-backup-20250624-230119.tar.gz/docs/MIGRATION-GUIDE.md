# 遷移指南：從傳統流程到現代化 AI 開發流程

## 🚀 快速總覽

我們簡化了開發流程，從 30+ 個命令精簡為 6 個核心命令。

### 命令對照表

| 舊命令 | 新命令 | 說明 |
|--------|--------|------|
| `make dev-start` | `make new` | 開始新工作 |
| `make dev-checkpoint` | `make save` | 保存進度 |
| `make dev-commit` + `make dev-done` | `make done` | 完成工作 |
| `make dev-check` | 已整合到 `make save` | 自動檢查 |
| `make dev-test` | `make test-smart` | 智能測試 |
| 30+ 其他命令 | 6 個核心命令 | 大幅簡化 |

## 📊 新增功能

### AI Token 追蹤
```bash
# 記錄 AI 使用
PROMPT_TOKENS=1500 COMPLETION_TOKENS=3000 make save

# 查看報告
make report
```

### 智能測試
```bash
# 自動偵測變更並執行相關測試
make test-smart
```

## 🔄 遷移步驟

### 1. 備份現有流程
```bash
# 已自動備份為 Makefile.legacy
ls Makefile.legacy
```

### 2. 使用新流程
```bash
# 查看新命令
make help

# 開始使用
make new TYPE=feature TICKET=my-feature
```

### 3. 票券格式變更

**舊格式**（複雜）：
```yaml
spec:
  goals: |
    詳細的目標描述...
  technical_specs: |
    技術規格說明...
  acceptance_criteria:
    - 條件1
    - 條件2
document_references:
  - path: docs/handbook/...
    reason: ...
```

**新格式**（極簡）：
```yaml
spec:
  feature: OAuth2 登入
  purpose: 快速登入
  acceptance_criteria:
    - 支援 OAuth2
    - 顯示使用者資訊
```

## ⚠️ 注意事項

1. **AI Token 記錄**：請記得在使用 AI 後記錄 tokens
2. **不再需要**：
   - 手動記錄文件參考
   - 複雜的 workflow guard 檢查
   - 多層級的確認步驟
3. **保留功能**：
   - 票券追蹤
   - Git 分支管理
   - 智能提交

## 💡 最佳實踐

1. **頻繁保存**：使用 `make save` 取代舊的 checkpoint
2. **記錄 AI 使用**：每次 AI 協助後記錄 tokens
3. **查看報告**：定期使用 `make report` 檢視效率

## 🆘 問題排解

### Q: 舊票券如何處理？
A: 可以繼續使用，系統向下相容。

### Q: 如何回到舊流程？
A: `cp Makefile.legacy Makefile`

### Q: AI metrics 追蹤失敗？
A: 確保已安裝 Python 3 和 PyYAML

## 📚 參考資源

- 新版 CLAUDE.md - AI 行為指南
- AI-QUICK-REFERENCE.md - 快速參考
- modern-ticket.yml - 新票券模板

---

遷移完成後，您將享受到：
- ⚡ 50% 效率提升
- 📊 完整的 AI 使用分析
- 🎯 更專注於核心開發
- 🤖 更好的 AI 協作體驗