# 新的 Docs 目錄結構提案

## 🎯 設計原則
- 極簡：減少 80% 的文件數量
- AI 友善：結構化、易解析
- 高效：快速找到需要的資訊

## 📁 建議結構

```
docs/
├── tickets/              # 票券管理（極簡化）
│   ├── active/          # 當前進行中的票券
│   └── archive/         # 已完成票券（按月壓縮）
│
├── handbook/            # 核心參考（單一文件）
│   └── AI-QUICK-REFERENCE.md
│
├── scripts/             # 核心腳本（5-8 個）
│   ├── ticket-manager.py
│   ├── ai-metrics.py
│   ├── smart-commit.py
│   └── workflow.py
│
└── reports/             # 自動生成的報告
    ├── weekly/          # 週報
    └── metrics/         # AI 使用指標
```

## 🗑️ 建議刪除/歸檔

### 立即刪除
- `__pycache__/` - Python 緩存
- `.DS_Store` - macOS 系統文件
- `archive/docs_backup_*/` - 用 git 管理版本

### 歸檔到 git history
- `dev-logs/` - 整合到 tickets
- `test-reports/` - 自動生成，不需保存
- `decisions/` - 整合到 handbook
- `stories/` - 整合到 tickets

### 精簡 scripts（從 57 個到 8 個）
保留：
1. `modern-ticket-manager.py` - 票券管理
2. `ai-metrics-tracker.py` - AI 追蹤
3. `smart-commit.py` - 智能提交
4. `workflow-guard.py` - 流程守護
5. `analytics.py` - 分析報告
6. `secret-detector.py` - 安全檢查
7. `archive-tickets.py` - 歸檔管理
8. `report-generator.py` - 報告生成

## 🔄 遷移計劃

### Phase 1: 立即執行（今天）
```bash
# 1. 備份
tar -czf docs-backup-$(date +%Y%m%d).tar.gz docs/

# 2. 清理垃圾
find docs -name "*.pyc" -o -name "__pycache__" -o -name ".DS_Store" -delete

# 3. 移除重複備份
rm -rf docs/archive/docs_backup_*
```

### Phase 2: 結構重組（明天）
```bash
# 1. 創建新結構
mkdir -p docs/new/{tickets/active,tickets/archive,handbook,scripts,reports/{weekly,metrics}}

# 2. 遷移核心文件
cp docs/handbook/AI-QUICK-REFERENCE.md docs/new/handbook/
cp docs/tickets/in_progress/* docs/new/tickets/active/

# 3. 遷移核心腳本
cp docs/scripts/{modern-ticket-manager,ai-metrics-tracker,smart-commit}.py docs/new/scripts/
```

### Phase 3: 完成遷移（後天）
```bash
# 1. 歸檔舊結構
mv docs docs-old
mv docs/new docs

# 2. 提交變更
git add -A
git commit -m "refactor: 簡化 docs 結構，減少 80% 文件"
```

## 📊 預期結果

| 指標 | 現在 | 改進後 |
|------|------|--------|
| 總文件數 | 687 | ~100 |
| 目錄層級 | 5-6 層 | 2-3 層 |
| scripts 數量 | 57 | 8 |
| handbook 文件 | 80+ | 1 |

## 🚀 效益

1. **查找速度提升 80%** - 更少的文件和目錄
2. **AI 解析效率提升** - 結構化和標準化
3. **維護成本降低 70%** - 極簡化管理
4. **新人上手時間減少 50%** - 單一參考文件